package Module_2.SportsTeamApp;

import java.util.Scanner;

public class TestSportsTeamApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter a team name: ");
        String teamName = input.nextLine();

        System.out.println("Enter the player names: ");
        System.out.println("Use commas for more than one player; no spaces: ");
        String playerNames = input.nextLine();

        Team team1 = new Team();
            
        }
    }
